from rest_framework import serializers
from .models import Service, Evenement, Commentaire


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = '__all__'


class EvenementSerializer(serializers.ModelSerializer):
    class Meta:
        model = Evenement
        fields = '__all__'

class CommentaireSerializer(serializers.ModelSerializer):
    service = Service.id
    service = serializers.PrimaryKeyRelatedField(read_only=True)
    class Meta:
        model = Commentaire
        fields = '__all__'