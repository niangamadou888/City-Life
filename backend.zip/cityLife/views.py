from .models import Commentaire, Service, Evenement
from .serializer import ServiceSerializer, EvenementSerializer, CommentaireSerializer
from rest_framework import generics



class ServiceDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer

class ServiceList(generics.ListCreateAPIView):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer


class EvenementDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Evenement.objects.all()
    serializer_class = EvenementSerializer

class EvenementList(generics.ListCreateAPIView):
    queryset = Evenement.objects.all()
    serializer_class = EvenementSerializer

class CommentaireList(generics.ListCreateAPIView):
    serializer_class = CommentaireSerializer

    def get_queryset(self):
        service_id = self.kwargs['service_id']
        return Commentaire.objects.filter(service_id=service_id)
    
    def perform_create(self, serializer):
        service_id = self.kwargs['service_id']
        service = generics.get_object_or_404(Service, pk=service_id)
        serializer.save(service=service)
    

class CommentaireDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Commentaire.objects.all()
    serializer_class = CommentaireSerializer

    def get_queryset(self):
        service_id = self.kwargs['service_id']
        return Commentaire.objects.filter(service_id=service_id)

    def get_object(self):
        queryset = self.get_queryset()
        obj = generics.get_object_or_404(queryset, pk=self.kwargs['pk'])
        return obj