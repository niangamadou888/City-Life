from django.urls import path
from django import urls
from .views import *
from . import views

from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('services/', ServiceList.as_view(), name='Services'),
    path('service/<int:pk>', ServiceDetail.as_view(), name='Service'),
    path('evenements/', EvenementList.as_view(), name='Evenements'),
    path('evenement/<int:pk>', EvenementDetail.as_view(), name='Evenement'),
    path('service/<int:service_id>/commentaires/', CommentaireList.as_view(), name='commentaire-list'),
    path('service/<int:service_id>/commentaire/<int:pk>/', CommentaireDetail.as_view(), name='commentaire-detail'),
]

urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)