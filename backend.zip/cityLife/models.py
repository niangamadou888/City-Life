from django.db import models
from django.utils import timezone

# Create your models here.

class Service(models.Model):
    ville = models.CharField(max_length=50)
    nomService = models.CharField(max_length=50)
    typeService = models.CharField(max_length=50)
    descriptionService = models.CharField(max_length=255)
    addressService = models.CharField(max_length=255)

    def __str__(self):
        return self.nomService


class Evenement(models.Model):
    ville = models.CharField(max_length=100)
    nomEvenement = models.CharField(max_length=50)
    descriptionEvenement = models.CharField(max_length=255)
    imageURL = models.CharField(max_length=255, blank=True)
    lieuEvenement = models.CharField(max_length=50)
    dateDebut = models.DateField()
    dateFin = models.DateField()
    

    def __str__(self):
        return self.nomEvenement
    

class Commentaire(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    utilisateur = models.CharField(max_length=50)
    contenuCommentaire = models.CharField(max_length=255)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.nomCommentaire
