from django.apps import AppConfig


class CitylifeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cityLife'
