import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Accueil',
    url: '/dashboard',
    iconComponent: { name: 'cil-home' }
  },
  {
    name: 'Services',
    iconComponent: { name: 'cil-pencil' },
    url: '/services'
  },
  {
    name: 'Evenement',
    iconComponent: { name: 'cil-list' },
    url: '/evenements'
  },
  {
    name: 'Maps',
    iconComponent: { name: 'cil-map' },
    url: '/maps'
  },
  {
    name: 'Contact',
    iconComponent: { name: 'cil-envelope-closed' },
    url: '/contact'
  },
];
