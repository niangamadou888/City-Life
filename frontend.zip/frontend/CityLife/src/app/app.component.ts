import { Component, Injectable, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { BrowserModule, Title } from '@angular/platform-browser';

import { IconSetService } from '@coreui/icons-angular';
import { iconSubset } from './icons/icon-subset';
import { ServiceService } from './views/services/service.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { EvenementService } from './views/evenements/evenement.service';
import { ServicesListComponent } from './views/services/services-list/services-list.component';
import { EvenementsListComponent } from './views/evenements/evenements-list/evenements-list.component';
import { CommonModule } from '@angular/common';
import { CreateServiceComponent } from './views/services/create-service/create-service.component';
import { FormControl, NgControl, NgModel, ReactiveFormsModule } from '@angular/forms';

@Injectable({ providedIn: 'root' })

@Component({
  selector: 'app-root',
  template: '<router-outlet />',
  standalone: true,
  imports: [RouterOutlet, HttpClientModule, ServicesListComponent, EvenementsListComponent, EvenementsListComponent, CreateServiceComponent, CommonModule, ReactiveFormsModule],
  providers: [ServiceService, HttpClient, EvenementService]
})
export class AppComponent implements OnInit {
  title = 'City Life';

  constructor(
    private router: Router,
    private titleService: Title,
    private iconSetService: IconSetService
  ) {
    this.titleService.setTitle(this.title);
    // iconSet singleton
    this.iconSetService.icons = { ...iconSubset };
  }

  ngOnInit(): void {
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
    });
  }
}
