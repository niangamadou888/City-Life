import { ContactComponent } from './contact.component';

import { Routes } from '@angular/router';


export const routes: Routes = [
  {
    path: '',
    component: ContactComponent,
    data: {
      title: 'Contact'
    }
  }
];