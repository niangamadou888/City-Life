import { Component, Injectable, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertComponent, ColComponent, FormCheckComponent, FormFeedbackComponent, InputGroupComponent } from '@coreui/angular';
import emailjs, { type EmailJSResponseStatus } from '@emailjs/browser';

@Injectable({ providedIn: 'root' })

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, FormsModule, ColComponent, FormFeedbackComponent, InputGroupComponent, FormCheckComponent, AlertComponent, ReactiveFormsModule],
  templateUrl: './contact.component.html'
})
export class ContactComponent implements OnInit{
  form: FormGroup = this.fb.group({
    from_name: '',
    to_name: 'Admin',
    from_email: '',
    from_subject: '',
    from_message: ''
  });

  constructor(private fb: FormBuilder){
    
  }

  ngOnInit(): void {
  }

  async send(){
    emailjs.init('4at3vsnqLIo6YTBNZ');
    let response = await emailjs.send("service_bsjdiu9","template_7m0j0mb",{
      from_name: this.form.value.from_name,
      from_email: this.form.value.from_email,
      from_subject: this.form.value.from_subject,
      from_message: this.form.value.from_message,
      });
      alert('Message has been sent.');
      this.form.reset()
      
  }


}
