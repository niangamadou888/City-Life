import { MapsComponent } from './maps.component';
import { Routes } from '@angular/router';


export const routes: Routes = [
  {
    path: '',
    component: MapsComponent,
    data: {
      title: 'Maps'
    }
  }
];