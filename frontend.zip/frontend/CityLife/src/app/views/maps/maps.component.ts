import { AfterViewInit, Component,OnInit } from '@angular/core';
import * as L from 'leaflet';
import "leaflet-control-geocoder/dist/Control.Geocoder.css";
import "leaflet-control-geocoder/dist/Control.Geocoder.js";

declare var google: any;

@Component({
    standalone: true,
    selector: 'maps-cmp',
    templateUrl: 'maps.component.html'
})

export class MapsComponent implements AfterViewInit {
    private map: L.Map | undefined;
    private geocoder : any;

  private initMap(): void {
    this.map = L.map('map', {
      center: [ 39.8282, -98.5795 ],
      zoom: 3
    });

    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      minZoom: 3,
      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    });

    

    tiles.addTo(this.map);
    (L.Control as any).geocoder().addTo(this.map);
    
    

    navigator.geolocation.watchPosition((pos)=>{
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;
      const accuracy = pos.coords.accuracy;
      L.marker([lat,lng]).addTo(this.map!);
      
    }, (error)=>{
      if(error.code === 1){
        alert("Please allow geolocation access");
      } else {
        alert("Cannot get location");
      }
      
    });
    
  }

    ngAfterViewInit(): void {
        this.initMap();
    }
    
}
