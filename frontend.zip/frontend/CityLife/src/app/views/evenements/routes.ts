import { AuthGuard } from 'src/app/auth.guard';
import { EvenementsListComponent } from './evenements-list/evenements-list.component';
import { Routes } from '@angular/router';


export const routes: Routes = [
  {
    path: '',
    component: EvenementsListComponent,
    data: {
      title: 'Evenements'
    }
  },
  {
    path: 'create-evenement',
    loadComponent: () => import('./create-evenement/create-evenement.component').then(m => m.CreateEvenementComponent),
    data: {
      title: 'Create Evenement'
    }
  },
  {
    path: 'evenement-details/:id',
    loadComponent: () => import('./evenement-details/evenement-details.component').then(m => m.EvenementDetailsComponent),
    data: {
      title: 'Details Evenement'
    },
  },
  {
    path: 'update-evenement/:id',
    loadComponent: () => import('./update-evenement/update-evenement.component').then(m => m.UpdateEvenementComponent),
    data: {
      title: 'Modifier Evenement'
    },
  },
];