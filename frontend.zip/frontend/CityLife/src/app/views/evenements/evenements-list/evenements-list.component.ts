import { FilterPipe } from './../../../filter.pipe';
import { Component } from '@angular/core';
import { Evenement } from '../evenement';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';
import { EvenementService } from '../evenement.service';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent } from '@coreui/angular';

@Component({
  selector: 'app-evenements-list',
  standalone: true,
  imports: [NgFor, NgIf, FilterPipe, FormsModule, CardComponent, CardBodyComponent],
  templateUrl: './evenements-list.component.html',
  styleUrl: './evenements-list.component.css'
})
export class EvenementsListComponent {
  evenements: Evenement[] | undefined;
  auth!: AuthService;
  searchText:any;
  constructor(private evenementService: EvenementService, private router: Router, private authService: AuthService){}

  ngOnInit(): void {
    this.getServices();
    this.auth = this.authService;
  }

  private getServices(){
  this.evenementService.getEvenementList().subscribe(data => {
    this.evenements = data;
  })
  }

  evenementDetails(id:number){
    this.router.navigate(['/evenements/evenement-details',id]);
  }

  goToCreateEvenement(){
    this.router.navigate(['/evenements/create-evenement']);
  }

  updateEvenement(id: number){
    this.router.navigate(['/evenements/update-evenement', id]);
  }

  deleteEvenement(id: number){
    this.evenementService.deleteEvenement(id).subscribe( data=> {
      console.log(data);
      this.getServices()
    })
  }
}
