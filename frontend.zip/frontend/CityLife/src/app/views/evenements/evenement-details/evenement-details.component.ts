import { Evenement } from './../evenement';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Service } from '../../services/service';
import { ServiceService } from '../../services/service.service';
import { EvenementService } from '../evenement.service';

@Component({
  selector: 'app-evenement-details',
  standalone: true,
  imports: [],
  templateUrl: './evenement-details.component.html',
  styleUrl: './evenement-details.component.css'
})
export class EvenementDetailsComponent {
  id!: number;
  evenement!:Evenement;

  constructor(private route: ActivatedRoute, private evenementService: EvenementService){}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.evenementService.getEvenementById(this.id).subscribe(data=>{
      this.evenement = data;
    })
  }
}
