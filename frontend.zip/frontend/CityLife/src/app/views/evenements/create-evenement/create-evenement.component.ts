import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Evenement } from '../evenement';
import { EvenementService } from '../evenement.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-evenement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './create-evenement.component.html',
  styleUrl: './create-evenement.component.css'
})
export class CreateEvenementComponent {
  evenement: Evenement = new Evenement();

  constructor(private evenementService: EvenementService, private router: Router){}


  saveEvenement(){
    this.evenementService.createEvenement(this.evenement).subscribe( data =>{
      console.log(data);
      this.goToEvenementList();
    },
    error => console.log(error));
  }
  
  goToEvenementList(){
    this.router.navigate(['/evenements']);
  }

  onSubmit(){
    console.log(this.evenement);
    this.saveEvenement();
  }
}
