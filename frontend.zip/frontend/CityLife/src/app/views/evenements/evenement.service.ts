import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Evenement } from './evenement';

@Injectable({
  providedIn: 'root'
})
export class EvenementService {
  private baseURL: string = "http://localhost:8000/api/";

  constructor(private httpClient: HttpClient) { }

  getEvenementList(): Observable<Evenement[]>{
    return this.httpClient.get<Evenement[]>(`${this.baseURL}evenements/`);
  }

  createEvenement(evenement: Evenement): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}evenements/`, evenement);
  }

  getEvenementById(id: number): Observable<Evenement>{
    return this.httpClient.get<Evenement>(`${this.baseURL}evenement/${id}`);
  }

  updateEvenement(id: number, evenement: Evenement): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}evenement/${id}`, evenement);
  }

  deleteEvenement(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}evenement/${id}`);
  }
}
