import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { EvenementsListComponent } from './evenements-list/evenements-list.component';
import { CreateEvenementComponent } from './create-evenement/create-evenement.component';
import { UpdateEvenementComponent } from './update-evenement/update-evenement.component';
import { AuthGuard } from '../auth.guard';
import { EvenementDetailsComponent } from './evenement-details/evenement-details.component';
import { EvenementService } from './evenement.service';

const EvenementsRoutes: Routes = [
  { path: 'services', component: EvenementsListComponent },
  { path: 'create-service', component: CreateEvenementComponent },
  { path: 'update-service/:id', component: UpdateEvenementComponent, canActivate:[AuthGuard] },
  { path: 'service-details/:id', component: EvenementDetailsComponent },
];



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(EvenementsRoutes)
  ],
  providers: [EvenementService]
})
export class EvenementsModule { }
