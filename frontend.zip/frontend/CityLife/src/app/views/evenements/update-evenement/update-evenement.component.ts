import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Evenement } from '../evenement';
import { EvenementService } from '../evenement.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-evenement',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './update-evenement.component.html',
  styleUrl: './update-evenement.component.css'
})
export class UpdateEvenementComponent {
  id!:number;
  evenement: Evenement = new Evenement();

  constructor(private evenementService: EvenementService, private route: ActivatedRoute, private router:Router){}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
      this.evenementService.getEvenementById(this.id).subscribe(data=>{
        this.evenement= data;
      }, error=>{
        console.log(error);
      });
  }

  goToEvenementList(){
    this.router.navigate(['/evenements']);
  }

  onSubmit(){
    this.evenementService.updateEvenement(this.id, this.evenement).subscribe(data=>{
      this.goToEvenementList();
    }, error=>{
      console.log(error);
    });
  }
}
