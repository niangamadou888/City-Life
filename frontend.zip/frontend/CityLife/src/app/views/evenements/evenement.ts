export class Evenement{
    id!: number
    ville!: string;
    nomEvenement!:string;
    descriptionEvenement!: string;
    lieuEvenement!: String;
    dateDebut!: Date;
    dateFin!: Date;
    imageURL?: string;
}