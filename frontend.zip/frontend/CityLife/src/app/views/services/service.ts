export class Service {
    id!: number;
    nomService!: string;
    typeService!: string;
    descriptionService!: string;
    addressService!: string;
    ville!: string;
    imageURL?: string;
}