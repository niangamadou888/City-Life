import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Commentaire } from '../Commentaire';
import { FormsModule, NgModel } from '@angular/forms';

@Component({
  selector: 'app-create-commentaire',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './create-commentaire.component.html',
  styleUrl: './create-commentaire.component.css'
})
export class CreateCommentaireComponent {
  id!: number;
  commentaire: Commentaire = new Commentaire();

  constructor(private route: ActivatedRoute,private serviceService: ServiceService, private router: Router){}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
  }


  saveCommentaire(){
    this.serviceService.createCommentaire(this.commentaire,this.id).subscribe( data =>{
      console.log(data);
      this.goToServiceDetails();
    },
    error => console.log(error));
  }
  
  goToServiceDetails(){
    this.router.navigate(['/services/service-details',this.id]);
  }

  onSubmit(){
    console.log(this.commentaire);
    this.saveCommentaire();
  }
}
