import { ServicesListComponent } from './services-list/services-list.component';
import { Routes } from '@angular/router';


export const routes: Routes = [
  {
    path: '',
    component: ServicesListComponent,
    data: {
      title: 'Services'
    },
  },
  {
    path: 'create-service',
    loadComponent: () => import('./create-service/create-service.component').then(m => m.CreateServiceComponent),
    data: {
      title: 'Create Service'
    }
  },
  {
    path: 'service-details/:id',
    loadComponent: () => import('./service-details/service-details.component').then(m => m.ServiceDetailsComponent),
    data: {
      title: 'Details Service'
    },
  },
  {
    path: 'create-commentaire/:id',
    loadComponent: () => import('./create-commentaire/create-commentaire.component').then(m => m.CreateCommentaireComponent),
    data: {
      title: 'Ajouter Commentaire'
    },
  },
  {
    path: 'update-service/:id',
    loadComponent: () => import('./update-service/update-service.component').then(m => m.UpdateServiceComponent),
    data: {
      title: 'Update Service'
    },
  },
];