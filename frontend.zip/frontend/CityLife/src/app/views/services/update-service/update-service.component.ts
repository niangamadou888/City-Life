import { Component } from '@angular/core';
import { Service } from '../service';
import { ServiceService } from '../service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update-service',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './update-service.component.html',
  styleUrl: './update-service.component.css'
})
export class UpdateServiceComponent {
  id!:number;
  service: Service = new Service();
  typeServiceChoices!: any[];
  villechoice!: any[];

  constructor(private serviceService: ServiceService, private route: ActivatedRoute, private router:Router){}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
      this.serviceService.getServiceById(this.id).subscribe(data=>{
        this.service= data;
      }, error=>{
        console.log(error);
      });
  }

  goToServiceList(){
    this.router.navigate(['/services']);
  }

  onSubmit(){
    this.serviceService.updateService(this.id, this.service).subscribe(data=>{
      this.goToServiceList();
    }, error=>{
      console.log(error);
    });
  }
}
