import { AuthGuard } from './../../auth.guard';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ServicesListComponent } from './services-list/services-list.component';
import { ServiceService } from './service.service';
import { CreateServiceComponent } from './create-service/create-service.component';
import { ServiceDetailsComponent } from './service-details/service-details.component';
import { UpdateServiceComponent } from './update-service/update-service.component';

const servicesRoutes: Routes = [
  { path: 'services', component: ServicesListComponent },
  { path: 'create-service', component: CreateServiceComponent },
  { path: 'update-service/:id', component: UpdateServiceComponent, canActivate:[AuthGuard] },
  { path: 'service-details/:id', component: ServiceDetailsComponent },
];



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(servicesRoutes)
  ],
  providers: [ServiceService]
})
export class ServiceModule { }
