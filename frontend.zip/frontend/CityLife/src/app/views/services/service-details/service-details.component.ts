import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Service } from '../service';
import { Commentaire } from '../Commentaire';
import { DatePipe, NgFor, NgIf } from '@angular/common';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-service-details',
  standalone: true,
  imports: [NgIf, NgFor, DatePipe],
  templateUrl: './service-details.component.html',
  styleUrl: './service-details.component.css'
})
export class ServiceDetailsComponent {
  id!: number;
  service!:Service;
  commentaires!: Commentaire[];
  auth!: AuthService;

  constructor(private route: ActivatedRoute, private serviceService: ServiceService, private authService: AuthService, private router: Router){}

  ngOnInit(): void {
    this.auth = this.authService;
    this.id = this.route.snapshot.params['id'];
    this.serviceService.getServiceById(this.id).subscribe(data=>{
      this.service = data;
    })
    this.serviceService.getCommentairesById(this.id).subscribe(data=>{
      this.commentaires = data;
    })
  }

  goToCreateCommentaire(id: number){
    this.router.navigate(['/services/create-commentaire',id]);
  }

  deleteCommentaire(id: number, idCom:number){
    this.serviceService.deleteCommentaire(id,idCom).subscribe( data=> {
      console.log(data);
      this.serviceService.getCommentairesById(this.id).subscribe(data => {
        this.commentaires = data;
      })
    })
  }
}
