export class Commentaire {
    id!: number;
    utilisateur!: string;
    contenuCommentaire!: string;
    created_at!: Date;
}