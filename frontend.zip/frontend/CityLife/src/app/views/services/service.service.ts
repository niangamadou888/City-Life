import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, catchError, of, tap } from 'rxjs';
import { Service } from './service';
import { Commentaire } from './Commentaire';

@Injectable({
  providedIn: 'root',
})
export class ServiceService {
  private baseURL: string = "http://localhost:8000/api/";

  constructor(private httpClient: HttpClient) { }

  getServiceList(): Observable<Service[]>{
    return this.httpClient.get<Service[]>(`${this.baseURL}services/`);
  }

  createService(service: Service): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}services/`, service);
  }

  getServiceById(id:number): Observable<Service>{
    return this.httpClient.get<Service>(`${this.baseURL}service/${id}`);
  }

  updateService(id: number, service: Service): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}service/${id}`, service);
  }

  deleteService(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}service/${id}`);
  }

  getCommentairesById(id:number): Observable<Commentaire[]>{
    return this.httpClient.get<Commentaire[]>(`${this.baseURL}service/${id}/commentaires/`);
  }

  deleteCommentaire(id:number, idCommentaire:number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}service/${id}/commentaire/${idCommentaire}/`);
  }

  createCommentaire(commentaire: Commentaire, id: number){
    return this.httpClient.post(`${this.baseURL}service/${id}/commentaires/`, commentaire);
  }

}
