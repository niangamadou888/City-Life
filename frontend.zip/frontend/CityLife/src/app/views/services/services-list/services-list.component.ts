import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { Service } from '../service';
import { ServiceService } from '../service.service';
import { AuthService } from 'src/app/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FilterPipe } from 'src/app/filter.pipe';
import { CardBodyComponent, CardComponent } from '@coreui/angular';

@Component({
  selector: 'app-services-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, FilterPipe, CardBodyComponent, CardComponent],
  templateUrl: './services-list.component.html',
  styleUrl:'./services-list.component.css'
})
export class ServicesListComponent {
  services: Service[] | undefined;
  auth!: AuthService;
  searchText:any;
  constructor(private serviceService: ServiceService, private router: Router, private authService: AuthService){}

  ngOnInit(): void {
    this.getServices();
    this.auth = this.authService;
  }

  private getServices(){
  this.serviceService.getServiceList().subscribe(data => {
    this.services = data;
  })
  }

  serviceDetails(id:number){
    this.router.navigate(['/services/service-details',id]);
  }

  goToCreateService(){
    this.router.navigate(['/services/create-service']);
  }

  updateService(id: number){
    this.router.navigate(['/services/update-service', id]);
  }

  deleteService(id: number){
    this.serviceService.deleteService(id).subscribe( data=> {
      console.log(data);
      this.getServices()
    })
  }
}
