import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Service } from '../service';
import { ServiceService } from '../service.service';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';

@Component({
  selector: 'app-create-service',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './create-service.component.html'
})
export class CreateServiceComponent {
  service: Service = new Service();

  constructor(private serviceService: ServiceService, private router: Router){}


  saveService(){
    this.serviceService.createService(this.service).subscribe( data =>{
      console.log(data);
      this.goToServiceList();
    },
    error => console.log(error));
  }
  
  goToServiceList(){
    this.router.navigate(['/services']);
  }

  onSubmit(){
    console.log(this.service);
    this.saveService();
  }
}
