import { Component, OnInit } from '@angular/core';
import {
  CardBodyComponent,
  CardComponent,
} from '@coreui/angular';

@Component({
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.scss'],
  standalone: true,
  imports: [CardBodyComponent,CardComponent]
})
export class DashboardComponent implements OnInit {

  ngOnInit(): void {
  }
}
