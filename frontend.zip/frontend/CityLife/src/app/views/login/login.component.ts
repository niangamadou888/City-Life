import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from 'src/app/auth.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CardBodyComponent, CardComponent, CardGroupComponent, ColComponent, ContainerComponent, InputGroupComponent, RowComponent } from '@coreui/angular';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, ContainerComponent, CardComponent, CardGroupComponent, CardBodyComponent, InputGroupComponent, ColComponent, RowComponent],
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  message: string = 'Vous étes déconnecté.';
  name!: string;
  password!: string;
  auth!: AuthService;

  constructor(private authService: AuthService, private router: Router){
    
  }


  ngOnInit(){
    this.auth = this.authService;
  }

  setMessage(){
    if(this.auth.isLoggedIn){
      this.message = 'Vous étes connnecté';
    } else {
      this.message = 'Identifiant ou mot de passe incorrect';
    }
  }

  login(){
    this.message = 'Tentative de connexion en cours';
    this.auth.login(this.name, this.password).subscribe((isLoggedIn: boolean)=>{
      if(isLoggedIn){
        this.message = 'Vous étes connnecté';
        this.router.navigate(['/services']);
      } else {
        this.password = '';
        this.router.navigate(['/login']);
      }
    });
  }

  logout(){
    this.auth.logout();
    this.message = 'Vous étes déconnecté'
  }
}
