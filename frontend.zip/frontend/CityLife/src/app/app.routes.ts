import { Routes } from '@angular/router';
import { DefaultLayoutComponent } from './layout';
import { CreateServiceComponent } from './views/services/create-service/create-service.component';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: '',
    component: DefaultLayoutComponent,
    data: {
      title: 'Home'
    },
    children: [
      {
        path: 'dashboard',
        loadChildren: () => import('./views/dashboard/routes').then((m) => m.routes)
      },
      {
        path: 'services',
        loadChildren: () => import('./views/services/routes').then((m) => m.routes)
      },
      {
        path: 'evenements',
        loadChildren: () => import('./views/evenements/routes').then((m) => m.routes)
      },
      {
        path: 'contact',
        loadChildren: () => import('./views/contact/routes').then((m) => m.routes)
      }
      ,
      {
        path: 'maps',
        loadChildren: () => import('./views/maps/routes').then((m) => m.routes)
      }
      ,
      {
        path: 'login',
        loadChildren: () => import('./views/login/routes').then((m) => m.routes)
      }
    ]
  },
  { path: '**', redirectTo: 'dashboard' }
];
