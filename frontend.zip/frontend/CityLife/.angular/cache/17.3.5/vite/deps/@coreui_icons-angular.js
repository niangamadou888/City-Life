import {
  IconComponent,
  IconDirective,
  IconModule,
  IconSetModule,
  IconSetService
} from "./chunk-V4YNR4LI.js";
import "./chunk-H2774DAX.js";
import "./chunk-UW6FWEOD.js";
import "./chunk-VLIYQAEX.js";
import "./chunk-WS5CSNII.js";
import "./chunk-SG3BCSKH.js";
import "./chunk-SAVXX6OM.js";
import "./chunk-PQ7O3X3G.js";
import "./chunk-UQ2RIRR7.js";
export {
  IconComponent,
  IconDirective,
  IconModule,
  IconSetModule,
  IconSetService
};
//# sourceMappingURL=@coreui_icons-angular.js.map
